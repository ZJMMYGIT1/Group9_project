package group9.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import group9.domain.Order;
import group9.service.OrderService;
import net.sf.json.JSONArray;

@Controller
public class OrderController {

	@Resource
	OrderService orderService;

	@ResponseBody
	@RequestMapping("/order.action")
	public void selectOrderList(HttpServletResponse resp) throws IOException {
		resp.setHeader("Content-Type", "text/html;charset=UTF-8");
		List<Order> list = orderService.selectAll();
		// list.add(new Order(1,"182639816","爽肤水","小王",350.0,"2019","已取消"));
		JSONArray jsonArray = JSONArray.fromObject(list);
		System.out.println(jsonArray + "1111111111111");
		String str = jsonArray.toString();
		resp.getWriter().write(str);
	}

	@ResponseBody
	@RequestMapping("/delete.action")
	public String deleteOrder(Integer id) {
		if (id == null) {
			return "error";
		}else {
			orderService.deleteById(id);
			return "success";
		}
	}

}
